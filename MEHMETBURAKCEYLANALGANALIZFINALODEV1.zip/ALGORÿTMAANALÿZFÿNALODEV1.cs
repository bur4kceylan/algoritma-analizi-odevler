﻿/*PRİMS ALGORİTMASI ÇALIŞMA MANTIĞI*/


//Ayrıtların bir alt kümesini, tüm düğümleri kapsayacak ve ayrıtların toplam ağırlığını minimum yapacak şekilde bulur.
//Bağlı olmayan bir çizgeye uygulandığında sonucu bağlı bileşenlerden yalnız birisi için bulur.
//Cycle oluşturmaması gerekir. Cycle yani kapalı bir alan.

/* PRİMS ALGORİTMASI*/
/*
    1-başla
    2-bir başlangıç düğümü seçiyorum. Diyelim ki bu düğüm "A". Bu düğümün key (anahtar) değerini 0 olarak belirliyorum ve diğer tüm düğümlerin key değerlerini sonsuz (∞) olarak ayarlıyorum. 
    Key değerleri, bir düğümü ağaca eklemek için gereken minimum kenar ağırlığını temsil eder.
    3-Tüm düğümleri ve kenarları yönetmek için bir min-heap (öncelik sırası yığını) kullanıyorum.
    Min-heap, her zaman en düşük ağırlıklı kenarı seçmemi sağlar. Ayrıca, minimum yayılı ağaca eklenen düğümleri takip etmek için bir küme oluşturuyorum.
    4-Min-heap'ten key değeri en düşük olan düğümü çıkarıyorum. Bu düğüm başlangıçta seçtiğim düğüm olan "A" olabilir.
    5-Bu düğümü minimum ağaca ekliyorum.
    6-Bu düğüme komşu olan tüm düğümleri inceliyorum. 
    Eğer komşu düğüm ağacın bir parçası değilse ve kenar ağırlığı bu komşu düğümün mevcut key değerinden küçükse, bu komşu düğümün key değerini ve ebeveyn (parent) düğümünü güncelliyorum.
    7-bu adımları tüm düğümler gezilene kadar tekrar eşiyorum.
 
 */

/* DJIKSTRA ALGORİTMASI ÇALIŞMA MANTIĞI*/
/* algoritma her adımda henüz işlenmemiş düğümler arasından en kısa mesafeye sahip olanı seçer ve bu düğümü işler.
 * Seçilen düğümün komşularının mesafelerini günceller ve ardından bir sonraki adıma geçer.
 * Bu işlem, hedef düğüme ulaşılıncaya kadar veya tüm düğümler işlenene kadar devam eder.*/


/*DJIKSTRA ALGORTMASI*/

/*
    1-başla
    2-üm tepelere gidiş maaliyetlerini sonsuz olarak işaretle.Başlangıç düğümünü gidildi olarak işaretle ve komşularının maaliyetlerini güncelle.
    3-Gidilmemiş (işaretlenmemiş) en ağırlıklı tepeyi bul , gidildi olarak işaretle.O tepeye komşu tepelerin ağırlıklarına bak .
    Eğer gelinen düğümün ağırlığı bakılan düğümün ağırlığından küçükse o tepeyi güncelle ve yolu not et.
    4-Tüm tepeler için adım 3'u tekrarla.
*/

/*KRUSKAL ALGORİTMASI ÇALIŞMA MANTIĞI*/
/* Kruskal algoritması,açgözlü bir algoritmadır, yani her adımda en iyiyi seçer 
 * ve bu seçimleri bir araya getirerek global bir optimuma ulaşmayı amaçlar. Bu nedenle, grafın tüm kenarlarını ağırlıklarına göre sıralamak,
 * algoritmanın başarılı bir şekilde çalışması için önemlidir.
 * Bu adım, algoritmanın zaman karmaşıklığını etkileyebilir, ancak tipik olarak ağaçlar için düşük bir karmaşıklıkla çalışır.  */

/* KRUSKAL ALGORİTMASI*/

/*
 *  1-başla
    2- İlk olarak, grafımızdaki tüm kenarları ağırlıklarına göre sıralarım. Bu sayede en hafif kenardan en ağır kenara doğru bir sıralama elde ederim.
    3-Algoritmayı başlatmak için boş bir minimum yayılı ağaç oluştururum. Bu ağaç, başlangıçta herhangi bir kenarı içermez.
    4- Her adımda, listenin başındaki en hafif kenarı seçerim.(cycle olmamasına dikkat ederim)
    5-cycle oluşmuyor ise bu düğümü ağaca eklerim
    6-ekledikten sonra ağacı gğncellerim
    7-Tüm kenarlar işlendikten sonra, minimum yayılı ağacım tamamlanmış olur. 
    8-bitir

*/
using System; // Gerekli kütüphaneleri dahil ediyoruz

class Algoritmalar
{
    static int V = 6; // Grafikteki düğüm sayısını belirtiyoruz

    // Prim Algoritması
    static int MinKey(int[] key, bool[] mstSet)
    {
        int min = int.MaxValue, minIndex = -1; // Min değeri başlangıçta en yüksek değere ayarlıyoruz

        for (int v = 0; v < V; v++) // Tüm düğümleri kontrol ediyoruz
        {
            if (mstSet[v] == false && key[v] < min) // Eğer düğüm MST'de değilse ve anahtarı min'den küçükse
            {
                min = key[v]; // Min anahtarını güncelliyoruz
                minIndex = v; // Min anahtarına sahip düğümün indeksini güncelliyoruz
            }
        }

        return minIndex; // Min anahtarına sahip düğümün indeksini döndürüyoruz
    }

    static void PrimMST(int[,] graph)
    {
        int[] parent = new int[V]; // MST'yi saklamak için dizi
        int[] key = new int[V]; // Anahtar değerlerini saklamak için dizi
        bool[] mstSet = new bool[V]; // MST'de olan düğümleri izlemek için dizi

        for (int i = 0; i < V; i++) // Tüm anahtarları en yüksek değere ve MST setini false olarak ayarlıyoruz
        {
            key[i] = int.MaxValue;
            mstSet[i] = false;
        }

        key[0] = 0; // İlk düğümü kök olarak alıyoruz ve anahtarını 0 yapıyoruz
        parent[0] = -1; // İlk düğümün parent'ı yok

        for (int count = 0; count < V - 1; count++) // Tüm düğümleri dahil edene kadar
        {
            int u = MinKey(key, mstSet); // Anahtarı en küçük olan düğümü seçiyoruz

            mstSet[u] = true; // Seçilen düğümü MST setine ekliyoruz

            for (int v = 0; v < V; v++) // Seçilen düğümün komşularını kontrol ediyoruz
            {
                if (graph[u, v] != 0 && mstSet[v] == false && graph[u, v] < key[v]) // Eğer düğüm MST'de değilse ve kenar ağırlığı anahtar değerinden küçükse
                {
                    parent[v] = u; // Parent'ı güncelliyoruz
                    key[v] = graph[u, v]; // Anahtar değerini güncelliyoruz
                }
            }
        }

        PrintMST(parent, graph); // MST'yi yazdırıyoruz

        int toplamAgirlik = 0; // Toplam ağırlığı hesaplamak için
        for (int i = 1; i < V; i++)
        {
            toplamAgirlik += graph[i, parent[i]]; // Her bir kenarın ağırlığını topluyoruz
        }
        Console.WriteLine("Prim Algoritması Toplam Ağırlık: " + toplamAgirlik); // Toplam ağırlığı yazdırıyoruz
    }

    // Dijkstra Algoritması
    static int MinMesafe(int[] mesafe, bool[] enKisaYolSeti)
    {
        int min = int.MaxValue, minIndex = -1; // Min değeri başlangıçta en yüksek değere ayarlıyoruz

        for (int v = 0; v < V; v++) // Tüm düğümleri kontrol ediyoruz
        {
            if (enKisaYolSeti[v] == false && mesafe[v] <= min) // Eğer düğüm en kısa yol setinde değilse ve mesafesi min'den küçük veya eşitse
            {
                min = mesafe[v]; // Min mesafesini güncelliyoruz
                minIndex = v; // Min mesafesine sahip düğümün indeksini güncelliyoruz
            }
        }

        return minIndex; // Min mesafesine sahip düğümün indeksini döndürüyoruz
    }

    static void Dijkstra(int[,] grafik, int kaynak)
    {
        int[] mesafe = new int[V]; // Kaynaktan diğer düğümlere olan mesafeleri saklamak için dizi
        bool[] enKisaYolSeti = new bool[V]; // En kısa yola dahil edilen düğümleri izlemek için dizi

        for (int i = 0; i < V; i++) // Tüm mesafeleri en yüksek değere ve seti false olarak ayarlıyoruz
        {
            mesafe[i] = int.MaxValue;
            enKisaYolSeti[i] = false;
        }

        mesafe[kaynak] = 0; // Kaynağın mesafesini 0 yapıyoruz

        for (int sayac = 0; sayac < V - 1; sayac++) // Tüm düğümler dahil olana kadar
        {
            int u = MinMesafe(mesafe, enKisaYolSeti); // Mesafesi en küçük olan düğümü seçiyoruz

            enKisaYolSeti[u] = true; // Seçilen düğümü set'e ekliyoruz

            for (int v = 0; v < V; v++) // Seçilen düğümün komşularını kontrol ediyoruz
            {
                if (!enKisaYolSeti[v] && grafik[u, v] != 0 && mesafe[u] != int.MaxValue && mesafe[u] + grafik[u, v] < mesafe[v]) // Eğer düğüm en kısa yol setinde değilse ve yeni mesafe daha küçükse
                {
                    mesafe[v] = mesafe[u] + grafik[u, v]; // Mesafeyi güncelliyoruz
                }
            }
        }

        CozumuYazdir(mesafe); // Sonuçları yazdırıyoruz

        int toplamMesafe = 0; // Toplam mesafeyi hesaplamak için
        for (int i = 0; i < V; i++)
        {
            toplamMesafe += mesafe[i]; // Her bir düğümün mesafesini topluyoruz
        }
        Console.WriteLine("Dijkstra Algoritması Toplam Mesafe: " + toplamMesafe); // Toplam mesafeyi yazdırıyoruz
    }

    // Kruskal Algoritması
    class Kenar : IComparable<Kenar>
    {
        public int Baslangic, Hedef, Agirlik; // Kenarın başlangıç, hedef düğümleri ve ağırlığı

        public int CompareTo(Kenar digerKenar) // Kenarları ağırlıklarına göre karşılaştırıyoruz
        {
            return this.Agirlik - digerKenar.Agirlik;
        }
    }

    static int[] parent = new int[V]; // Düğümün parent'ını izlemek için dizi

    static int Find(int i)
    {
        if (parent[i] == -1) // Eğer parent -1 ise
            return i; // Düğümün kendisini döndürüyoruz
        return Find(parent[i]); // Değilse parent'ını buluyoruz
    }

    static void Union(int x, int y)
    {
        int xSet = Find(x); // x düğümünün kökünü buluyoruz
        int ySet = Find(y); // y düğümünün kökünü buluyoruz
        parent[xSet] = ySet; // xSet'i ySet'e bağlıyoruz
    }

    static void KruskalMST(Kenar[] kenarlar)
    {
        Array.Sort(kenarlar); // Kenarları ağırlıklarına göre sıralıyoruz

        int e = 0; // Sonuç dizisi için başlangıç değeri
        int i = 0; // Kenar indeksi
        Kenar[] sonuc = new Kenar[V - 1]; // Sonuç dizisi

        for (i = 0; i < V; ++i)
            parent[i] = -1; // Parent dizisini -1 olarak başlatıyoruz

        i = 0;

        int toplamAgirlik = 0; // Toplam ağırlığı hesaplamak için

        while (e < V - 1) // Tüm kenarlar eklenene kadar
        {
            Kenar nextEdge = kenarlar[i++]; // Sıradaki kenarı alıyoruz

            int x = Find(nextEdge.Baslangic); // Başlangıç düğümünün kökünü buluyoruz
            int y = Find(nextEdge.Hedef); // Hedef düğümünün kökünü buluyoruz

            if (x != y) // Eğer aynı kökte değillerse
            {
                sonuc[e++] = nextEdge; // Kenarı sonuç dizisine ekliyoruz
                Union(x, y); // Düğümleri birleştiriyoruz
                toplamAgirlik += nextEdge.Agirlik; // Ağırlığı topluyoruz
            }
        }

        Console.WriteLine("Kenar \tAğırlık");
        Console.WriteLine("Kenar \tAğırlık");
        for (i = 0; i < e; ++i) // Sonuç dizisini yazdırıyoruz
            Console.WriteLine(sonuc[i].Baslangic + " - " + sonuc[i].Hedef + "\t" + sonuc[i].Agirlik);

        // Toplam ağırlığı yazdır
        Console.WriteLine("Kruskal Algoritması Toplam Ağırlık: " + toplamAgirlik);
    }

    // Ortak fonksiyonlar

    // Minimum Geren Ağacı veya En Kısa Yolu Yazdırma
    static void PrintMST(int[] parent, int[,] graph)
    {
        Console.WriteLine("Kenar \tAğırlık");
        for (int i = 1; i < V; i++) // Her bir kenarı ve ağırlığını yazdırıyoruz
        {
            Console.WriteLine(parent[i] + " - " + i + "\t" + graph[i, parent[i]]);
        }
    }

    // Dijkstra Algoritması çözümünü yazdırma
    static void CozumuYazdir(int[] mesafe)
    {
        Console.WriteLine("Düğüm \tEn Kısa Yol Uzunluğu");
        for (int i = 0; i < V; i++) // Her bir düğüm ve mesafesini yazdırıyoruz
        {
            Console.WriteLine(i + " \t" + mesafe[i]);
        }
    }

    // Ana Program
    static void Main(string[] args)
    {
        // Örnek grafiği oluşturuyoruz
        int[,] graph = new int[,] { { 0, 3, 1, 6, 0, 0 },
                                     { 3, 0, 5, 0, 3, 0 },
                                     { 1, 5, 0, 5, 6, 4 },
                                     { 6, 0, 5, 0, 0, 2 },
                                     { 0, 3, 6, 0, 0, 6 },
                                     { 0, 0, 4, 2, 6, 0 } };

        PrimMST(graph); // Prim Algoritması ile Minimum Geren Ağacı bulma

        Console.WriteLine("\n-----------------------------------------\n");

        Dijkstra(graph, 0); // Dijkstra Algoritması ile En Kısa Yolu bulma

        Console.WriteLine("\n-----------------------------------------\n");

        // Örnek kenarlar için dizi oluşturma
        Kenar[] kenarlar = new Kenar[9];
        kenarlar[0] = new Kenar() { Baslangic = 0, Hedef = 1, Agirlik = 3 };
        kenarlar[1] = new Kenar() { Baslangic = 0, Hedef = 2, Agirlik = 1 };
        kenarlar[2] = new Kenar() { Baslangic = 0, Hedef = 3, Agirlik = 6 };
        kenarlar[3] = new Kenar() { Baslangic = 1, Hedef = 2, Agirlik = 5 };
        kenarlar[4] = new Kenar() { Baslangic = 1, Hedef = 4, Agirlik = 3 };
        kenarlar[5] = new Kenar() { Baslangic = 2, Hedef = 3, Agirlik = 5 };
        kenarlar[6] = new Kenar() { Baslangic = 2, Hedef = 4, Agirlik = 6 };
        kenarlar[7] = new Kenar() { Baslangic = 2, Hedef = 5, Agirlik = 4 };
        kenarlar[8] = new Kenar() { Baslangic = 3, Hedef = 5, Agirlik = 2 };

        KruskalMST(kenarlar); // Kruskal Algoritması ile Minimum Geren Ağacı bulma

        Console.ReadKey(); // Programın sonunu beklemek için
    }
}


/* ALGORİTMALARIN ZAMAN KARMAŞIKLIĞI*/


/*PRİMS ALGORİTMASI
Min-Heap kullanılırsa;
O(ElogV)
Basit dizi kullanılarak: 
𝑂(V^2)
Bu kodda basit dizi kullanılıyor, bu nedenle zaman karmaşıklığı 
𝑂(V^2)

DIJKSTRA ALGORİTMASI
Min-Heap kullanılırsa;
O(ElogV)
Basit dizi kullanılarak: 
𝑂(V^2)
Bu kodda basit dizi kullanılıyor, bu nedenle zaman karmaşıklığı 
𝑂(V^2)

KRUSKAL ALGORİTMASI
O(ElogV)

---------ZAMAN KARMAŞIKLIKLARI BU ŞEKİLDEDİR-------------
*/